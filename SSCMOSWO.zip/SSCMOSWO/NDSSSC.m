function Population = NDSSSC(Population,N,Z,Zmin)
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    if isempty(Zmin)
        Zmin = ones(1,size(Z,2));
    end
    %% Non-dominated sorting（NDS)
    [FrontNo,MaxFNo] = NDSort(Population.objs,Population.cons,N); 
    %% More sparse solutions are selected based on the SSC mechanism.
    %% Population for next generation
    Population = Population(Next);
end
